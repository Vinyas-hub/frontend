import { Input,Button,Paper } from "@mui/material";
import { useContext, useState } from "react";
import { ProfileContext } from "../context/profilecontext";
import axios from "axios";
function Logout()
{
    const [response,setResponse]=useState()
    const [message,setMessage]=useState()
    const [userType,setUserType]=useState() 
    const [userTypeValidation,setUserTypeValidation]=useState()
    const [userId,setUserId]=useState() 
    const [userIdValidation,setUserIdValidation]=useState()
    const [navigationmesasge,setNavigationMessage]=useState()

    return (<div>
        <Paper elevation={4} style={{marginTop:"30px",width:"566px", marginLeft:"400px"}}>
            <div style={{marginLeft:"150px"}}>

            <h1>LOGOUT</h1>
        Enter userId <br/><Input type='text' onChange={(e)=>{setUserId(e.target.value)}} /> <br/>
        <p style={{color:"red"}}>{userIdValidation}</p> 
       
        Enter userType <br/><Input type='text' onChange={(e)=>{setUserType(e.target.value)}} /> <br/>
        <p style={{color:"red"}}>{userTypeValidation}</p> 
        
              <Button style={{marginLeft:"50px"}} variant="outlined" onClick={()=>{

var Login={
    userId:userId,
    userType:userType
        }
        let url='http://localhost:8090/user/logout'
      let headers={
        'Content-Type':'application/json'
    }
    axios.post(url,Login,{headers}).then((e)=>{
         console.log(e.data)
         setResponse(e.data)        //to show that hook

        }).catch((e)=>{
             console.log(e)
            })
                 if(userId==undefined)
                {
                    setUserTypeValidation("user name is blank")
                }
                else
                {
                    setUserTypeValidation(" ")
                }
                

                if(userType==undefined)
                {
                    setUserTypeValidation("password is blank")
                }
                else
                {
                    setUserTypeValidation(" ")
                }
                if(userId==userId && userType==userType ){
                    setMessage("logout sucessfilly");
                    window.location.href = '/HomeImg';
                }
                else{
                    setMessage("Invalid");
 
                }

            }}> Logout</Button> </div>
            {navigationmesasge}
            </Paper>
    </div>)

}
export default Logout