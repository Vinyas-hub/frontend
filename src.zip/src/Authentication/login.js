import { Input,Button,Paper } from "@mui/material";
import { useContext, useState } from "react";
import { ProfileContext } from "../context/profilecontext";
import axios from "axios";
function Login()
{
    const [response,setResponse]=useState()
    const [message,setMessage]=useState()

    const [session_key,setSession_key]=useState()
    const [session_keyValidation,setSession_keyValidation]=useState()
   const [email,setEmail]=useState()
   const [emailValidation,setEmailValidation]=useState()
    const [password,setPassword]=useState() 
    const [passwordValidation,setPasswordValidation]=useState()
    const [userType,setUserType]=useState() 
    const [userTypeValidation,setUserTypeValidation]=useState()
    const [navigationmesasge,setNavigationMessage]=useState()

    return (<div>
        <Paper elevation={4} style={{marginTop:"130px",width:"566px", marginLeft:"400px"}}>
            <div style={{marginLeft:"150px"}}>

            <h1>LOGIN</h1>
            
            Enter SessionId <br/><Input type='text'  onChange={(e)=>{setSession_key(e.target.value)}} /> <br/>
        <p style={{color:"red"}}>{session_keyValidation}</p>
        Enter email <br/><Input type='text' onChange={(e)=>{setEmail(e.target.value)}} /> <br/>
        <p style={{color:"red"}}>{emailValidation}</p> 
        Enter password <br/><Input type='text' onChange={(e)=>{setPassword(e.target.value)}} /> <br/>
        <p style={{color:"red"}}>{passwordValidation}</p>
        Enter userType <br/><Input type='text' onChange={(e)=>{setUserType(e.target.value)}} /> <br/>
        <p style={{color:"red"}}>{userTypeValidation}</p> 
        
              <Button style={{marginLeft:"50px"}} variant="outlined" onClick={()=>{

var Login={
    session_key:session_key,
    email:email,
    password:password,
    userType:userType
        }
        let url='http://localhost:8090/user/login?sessionKey='+session_key 
      let headers={
        'Content-Type':'application/json'
    }
    axios.post(url,Login,{headers}).then((e)=>{
         console.log(e.data)
         setResponse(e.data)        //to show that hook

        }).catch((e)=>{
             console.log(e)
            })

            if(session_key==undefined)
            {
                setSession_keyValidation("session_key is blank")
            }
                 if(email==undefined)
                {
                    setEmailValidation("user name is blank")
                }
                else
                {
                    setEmailValidation(" ")
                }
                if(password==undefined)
                {
                    setPasswordValidation("password is blank")
                }
                else
                {
                    setPasswordValidation(" ")
                }

                if(userType==undefined)
                {
                    setUserTypeValidation("password is blank")
                }
                else
                {
                    setUserTypeValidation(" ")
                }
                window.location.href = '/admin/dashboard';

            }}> login</Button> </div>
            {navigationmesasge}
            </Paper>
    </div>)

}
export default Login