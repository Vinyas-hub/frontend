export const ItemArray=[{
    itemName:"Coffee",
    price:20,
    quantity:10},
    {
        itemName:"Espresso",
    price:25,
    quantity:15
    },
    {
        itemName:"Latte",
        price:35,
        quantity:27 
    },
    {
        itemName:"Black Coffee",
        price:45,
        quantity:29 
    }]