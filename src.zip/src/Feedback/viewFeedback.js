import { Input,Button,Paper, Card } from "@mui/material";
import { useContext, useState } from "react";
import { ProfileContext } from "../context/profilecontext";
import axios from "axios";  
import { Feedback } from "@mui/icons-material";
const [session_key,setSession_key]=useState()

function ViewFeedback()
{  
return (<div>
  <Paper elevation={4} style={{marginTop:"30px",width:"566px", marginLeft:"400px"}}>
  <div style={{marginLeft:"150px"}}>
      <h1>view Feedback</h1>

      Enter Session Key<br/><Input type='text'  onChange={(e)=>{setSession_key(e.target.value)}} /> <br/>
  <p style={{color:"red"}}>{session_keyValidation}</p>

  <Button style={{marginLeft:"50px"}} variant="outlined" onClick={()=>{

var Feedback={
    session_key:session_key
}
let url='http://localhost:8090/feedbacks/viewallfeedbacks?sessionKey='+session_key
      let headers={
        'Content-Type':'application/json'
    }
    axios.post(url,Feedback,{headers}).then((e)=>{
         console.log(e.data)
         setResponse(e.data)    
        }).catch((e)=>{
             console.log(e)
            })
            if(session_key==undefined)
            {
                setSession_keyValidation("session_key is blank")
            }


}}> Submit</Button> 

<br/>


</div>
</Paper>

</div>);
}
export default ViewFeedback