
import { Input,Button,Paper } from "@mui/material";
import { useContext, useState } from "react";
import { ProfileContext } from "../context/profilecontext";
import axios from "axios";

 

function AddHotel()
{

    const [selectedOption, setSelectedOption] = useState('option1');
    // initialize the selected option state with the first option as default
    
    const [hotel_Id,setHotelID]=useState()
    const [hotelIdValidation,setHotelIDValidation]=useState()
    const [hotelName,setHotelName]=useState()
    const [hotelNameValidation,setHotelNameValidation]=useState()
    const [hotelDescription,setHotelDescription]=useState()
    const [hotelDescriptionValidation,setHotelDescriptionValidation]=useState()
    const [hotelAddress,setHotelAddress]=useState()
    const [hotelAddressValidation,setHotelAddressValidation]=useState()
    const [hotelRent,setHotelRent]=useState()
    const [hotelRentValidation,setHotelRentValidation]=useState()
    const [message,setMessage]=useState()




  
    const handleOptionChange = (event) => {
      setSelectedOption(event.target.value);
    }

    return (<div>
        <Paper elevation={4} style={{marginTop:"30px",width:"566px", marginLeft:"400px"}}>
        <div style={{marginLeft:"150px"}}>
            <h1>Add Hotel</h1>
        Enter HotelID <br/><Input type='text'  value={hotel_Id} inputProps={{"hotel-testid":"hotel_Id"}}
        onChange={(e)=>{setHotelID(e.target.value)}} /> <br/>
        <p style={{color:"red"}}>{hotelIdValidation}</p> 
        Enter Hotel Name <br/><Input type='text' value={hotelName} inputProps={{"hotel-testid":"hotelName"}}
        onChange={(e)=>{setHotelName(e.target.value)}}  /> <br/>
        <p style={{color:"red"}}>{hotelNameValidation}</p> 
        <div>
      <label htmlFor="dropdown"> Enter Hotel Type </label>
      <br/>
      <br/>
      <select id="dropdown" value={selectedOption}
      onChange={handleOptionChange}>
        <option value="NON_AC">NON AC</option>
        <option value="AC">AC</option>
        <option value="THREE_STAR">THREE STAR</option>
        <option value="FOUR_STAR">FOUR STAR</option>
        <option value="FIVE_STAR">FIVE STAR </option>
      </select>
      <p style={{color:"green"}}>You selected: {selectedOption}</p>
    </div>
       
        <p style={{color:"red"}}>{}</p> 
        Enter Hotel Description <br/><Input type='text' value={hotelDescription} inputProps={{"hotel-testid":"hotelDescription"}}
        onChange={(e)=>{setHotelDescription(e.target.value)}}    /> <br/>
        <p style={{color:"red"}}>{hotelDescriptionValidation}</p> 
        Enter Hotel Address <br/><Input type='text' value={hotelAddress} inputProps={{"hotel-testid":"hotelAddress"}} 
        onChange={(e)=>{setHotelAddress(e.target.value)}}    /><br/>
        <p style={{color:"red"}}>{hotelAddressValidation}</p>
        Enter Hotel Rent <br/><Input type='text' value={hotelRent} inputProps={{"hotel-testid":"hotelRent"}} 
        onChange={(e)=>{setHotelRent(e.target.value)}}   /> <br/>
        <p style={{color:"red"}}>{hotelRentValidation}</p>
       
        <div>
      <label htmlFor="dropdown"> Enter Hotel Status </label>
      <br/>
      <br/>
      <select id="dropdown" value={selectedOption} onChange={handleOptionChange}>
        <option value="SOLD_OUT">SOLD OUT</option>
        <option value="ROOM_AVAILABLE">ROOM AVAILABLE</option>
      </select>
      <p style={{color:"green"}}>You selected: {selectedOption}</p>
    </div>
    <Button style={{marginLeft:"50px"}} variant="outlined" onClick={()=>{
                 if(hotel_Id==undefined)
                {
                    setHotelIDValidation("hotel ID is blank")
                }
                else if(hotel_Id.length<3)
                {
                    setHotelIDValidation("hotel ID  less then 3")
                }else
                {
                    setHotelIDValidation(" ")
                }


                if(hotelName==undefined)
                {
                    setHotelNameValidation("hotelName is blank")
                }
                else if(hotelName.length<3)
                {
                    setHotelNameValidation("hotelName less then 3 words")
                }else
                {
                    setHotelNameValidation(" ")
                }
               
                if(hotelDescription==undefined)
                {
                    setHotelDescriptionValidation("HotelDescription is blank")
                }
                else if(hotelDescription.length<10)
                {
                    setHotelDescriptionValidation("HotelDescription must be described in 10 to 1000 Character")
                }else
                {
                    setHotelDescriptionValidation(" ")
                }


                if(hotelAddress==undefined)
                {
                    setHotelAddressValidation("user name is blank")
                }
                else if(hotelAddress.length<3)
                {
                    setHotelAddressValidation("user name less then 3")
                }else
                {
                    setHotelAddressValidation(" ")
                }


                if(hotelRent==undefined)
                {
                    setHotelRentValidation("HotelRentis blank")
                }
                else if(hotelRent.length<2000)
                {
                    setHotelRentValidation("HotelRent is less then 2000/")
                }else
                {
                    setHotelRentValidation(" ")
                }

            }}> Submit</Button> 
        </div>
        </Paper>
        
    </div>);
    
}
export default AddHotel